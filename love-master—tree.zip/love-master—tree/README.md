# 爱心树表白
表白示范：
https://xfbxfbxfb.github.io/love/
- 只需输入对方的名字，表白任何人
- 不过对方是男的就尴尬啦
